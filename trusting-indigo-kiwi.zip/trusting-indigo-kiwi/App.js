import React, { useState, useEffect } from 'react';
import { StyleSheet, View, ImageBackground, Text, TouchableOpacity, SafeAreaView, ScrollView, Alert, Linking, Dimensions } from 'react-native';

const { width } = Dimensions.get('window');

export default function App() {
  const [isLocked, setIsLocked] = useState(true);
  const [page, setPage] = useState('home');
  const [time, setTime] = useState(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }));

  useEffect(() => {
    const timer = setInterval(() => {
      setTime(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // --- ANDROID SPECIFIC LAUNCHERS ---
  const launchAndroid = (url) => {
    Linking.openURL(url).catch(() => {
      Alert.alert("System Error", "This system function is restricted on Catphone 22.");
    });
  };

  if (isLocked) {
    return (
      <ImageBackground source={{ uri: 'https://i.ibb.co/ynd5BXtT/Cat-Phone-Bc.png' }} style={styles.bg}>
        <SafeAreaView style={styles.lockContainer}>
          <Text style={styles.lockTime}>{time}</Text>
          <Text style={styles.lockDate}>Wednesday, December 25</Text>
          <TouchableOpacity style={styles.unlockBtn} onPress={() => setIsLocked(false)}>
            <Text style={styles.unlockText}>▲ SWIPE UP TO UNLOCK</Text>
          </TouchableOpacity>
        </SafeAreaView>
      </ImageBackground>
    );
  }

  return (
    <ImageBackground source={{ uri: 'https://i.ibb.co/ynd5BXtT/Cat-Phone-Bc.png' }} style={styles.bg}>
      <View style={styles.overlay}>
        <SafeAreaView style={styles.flex}>
          <View style={styles.sb}>
            <Text style={styles.st}>{time}</Text>
            <Text style={styles.st}>📶 🔋 100%</Text>
          </View>

          {page === 'home' ? (
            <View style={styles.flex}>
              <View style={styles.grid}>
                <Icon n="Messages" c="#00d4ff" i="✉️" on={() => setPage('chat')} />
                <Icon n="KitStore" c="#ffd11a" i="🛍️" on={() => setPage('store')} />
                <Icon n="Radar" c="#ff4d4d" i="🛰️" on={() => launchAndroid('geo:0,0?q=cats')} />
                <Icon n="YouTube" c="#ff0000" i="📺" on={() => launchAndroid('https://www.youtube.com')} />
              </View>

              <View style={styles.grid}>
                <Icon n="Dialer" c="#4CAF50" i="📞" on={() => launchAndroid('tel:')} />
                <Icon n="Photos" c="#66bb6a" i="🖼️" on={() => launchAndroid('content://media/internal/images/media')} />
                <Icon n="Play Store" c="#fff" i="▶️" on={() => launchAndroid('market://details?id=com.google.android.youtube')} />
              </View>

              <View style={styles.dock}>
                <TouchableOpacity onPress={() => setPage('chat')}><Text style={styles.di}>✉️</Text></TouchableOpacity>
                <TouchableOpacity onPress={() => setIsLocked(true)}><Text style={styles.di}>🔒</Text></TouchableOpacity>
                <TouchableOpacity onPress={() => setPage('store')}><Text style={styles.di}>🛍️</Text></TouchableOpacity>
              </View>
            </View>
          ) : page === 'chat' ? (
            <MessageLog setPage={setPage} />
          ) : (
            <StoreApp setPage={setPage} onOpenYoutube={() => launchAndroid('https://www.youtube.com')} />
          )}
        </SafeAreaView>
      </View>
    </ImageBackground>
  );
}

// Sub-components
const Icon = ({ n, c, i, on }) => (
  <TouchableOpacity style={styles.ic} onPress={on}>
    <View style={[styles.pl, { backgroundColor: c }]}><Text style={{fontSize: 30}}>{i}</Text></View>
    <Text style={styles.il}>{n}</Text>
  </TouchableOpacity>
);

const MessageLog = ({ setPage }) => (
  <View style={styles.app}>
    <Text style={styles.title}>Space Messages</Text>
    <ScrollView>
        <Msg s="Santa" t="Oh whats this?" c="#ff4d4d" />
        <Msg s="Spacekit" t="Happy Birthday!" c="#00d4ff" />
        <Msg s="Santa" t="You mean Christmas" c="#ff4d4d" />
        <Msg s="Spacekit" t="yeah...." c="#00d4ff" />
        <Msg s="Santa" t="Merry Christmas Anakin This is your Christmas present!" c="#ff4d4d" />
    </ScrollView>
    <TouchableOpacity style={styles.btn} onPress={() => setPage('home')}><Text style={styles.bt}>HOME</Text></TouchableOpacity>
  </View>
);

const StoreApp = ({ setPage, onOpenYoutube }) => (
  <View style={styles.app}>
    <Text style={styles.title}>KitStore 🐈‍⬛</Text>
    <ScrollView>
      <TouchableOpacity style={styles.storeItem} onPress={onOpenYoutube}>
        <View style={styles.flex}>
          <Text style={styles.bt}>YouTube</Text>
          <Text style={{color: '#bbb', fontSize: 12}}>Official Video App</Text>
        </View>
        <Text style={{color: '#ff4d4d', fontWeight: 'bold'}}>OPEN</Text>
      </TouchableOpacity>
    </ScrollView>
    <TouchableOpacity style={styles.btn} onPress={() => setPage('home')}><Text style={styles.bt}>HOME</Text></TouchableOpacity>
  </View>
);

const Msg = ({ s, t, c }) => (
  <View style={[styles.bubble, { borderLeftColor: c }]}><Text style={{color: c, fontWeight: 'bold'}}>{s}</Text><Text style={{color: 'white'}}>{t}</Text></View>
);

const styles = StyleSheet.create({
  bg: { flex: 1, width: '100%', height: '100%' },
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.1)' },
  flex: { flex: 1 },
  lockContainer: { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: 'rgba(0,0,0,0.4)' },
  lockTime: { fontSize: 85, color: 'white', fontWeight: '200', marginTop: 50 },
  lockDate: { fontSize: 20, color: 'white', marginBottom: 'auto' },
  unlockBtn: { marginBottom: 50, padding: 20 },
  unlockText: { color: 'white', letterSpacing: 3, fontSize: 14, opacity: 0.9 },
  sb: { flexDirection: 'row', justifyContent: 'space-between', paddingHorizontal: 25, paddingTop: 10 },
  st: { color: 'white', fontSize: 14, fontWeight: 'bold' },
  grid: { flexDirection: 'row', justifyContent: 'flex-start', flexWrap: 'wrap', padding: 20 },
  ic: { width: (width - 40) / 4, alignItems: 'center', marginBottom: 30 },
  pl: { width: 60, height: 60, borderRadius: 18, justifyContent: 'center', alignItems: 'center', elevation: 4 },
  il: { color: 'white', fontSize: 11, marginTop: 8, fontWeight: '600' },
  dock: { backgroundColor: 'rgba(255, 255, 255, 0.3)', marginHorizontal: 20, marginBottom: 25, padding: 15, borderRadius: 35, flexDirection: 'row', justifyContent: 'space-around', marginTop: 'auto' },
  di: { fontSize: 32 },
  app: { flex: 1, backgroundColor: '#000', margin: 15, borderRadius: 30, padding: 20 },
  title: { color: 'white', fontSize: 22, fontWeight: 'bold', textAlign: 'center', marginBottom: 20 },
  bubble: { padding: 15, backgroundColor: '#151515', borderRadius: 15, marginBottom: 12, borderLeftWidth: 4 },
  storeItem: { flexDirection: 'row', backgroundColor: '#151515', padding: 18, borderRadius: 15, marginBottom: 10, alignItems: 'center' },
  btn: { padding: 15, backgroundColor: '#222', borderRadius: 20, alignItems: 'center', marginTop: 10 },
  bt: { color: 'white', fontWeight: 'bold' }
});